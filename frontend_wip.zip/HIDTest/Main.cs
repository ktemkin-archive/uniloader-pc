using System;
using System.Configuration;

using Unilab.Programming;

namespace HIDTest
{
	class MainClass
	{
		//FIXME: These should be extracted to a config file once I figure out 
		//what's going on with ConfigurationManager and mono.
		
		/**
		#define VENDOR_ID		0x16C0
		#define PRODUCT_ID		0x0480
		#define RAWHID_USAGE_PAGE	0xFFAB	// recommended: 0xFF00 to 0xFFFF
		#define RAWHID_USAGE		0x0200	// recommended: 0x0100 to 0xFFFF
		*/
		

		
		public static void Main (string[] args)
		{
			
			
		}
	}
}

