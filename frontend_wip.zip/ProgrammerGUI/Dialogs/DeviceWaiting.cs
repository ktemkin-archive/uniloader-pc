using System;
namespace ProgrammerGUI
{
	public partial class DeviceWaiting : Gtk.Dialog
	{
		public DeviceWaiting ()
		{
			this.Build ();
		}
	}
}

