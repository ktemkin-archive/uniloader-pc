using System;


namespace Application
{
	public class WinformsTest 
	{
		public WinformsTest ()
		{
		}
	}
}

