using System;
namespace Unilab
{
	public class MyClass
	{
		public MyClass ()
		{
		}
	}
}

