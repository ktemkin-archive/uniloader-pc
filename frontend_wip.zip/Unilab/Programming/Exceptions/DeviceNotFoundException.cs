using System;

namespace Unilab.Programming
{
	public class DeviceNotFoundException : Exception
	{
		public DeviceNotFoundException ()
		{
			
		}
	}
}

