using System;
namespace Unilab
{
	public class DeviceInUseException : Exception
	{
		public DeviceInUseException ()
		{
		}
	}
}

